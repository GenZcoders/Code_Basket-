
<?php $__env->startSection('main-section'); ?>
<style>
    /* .uu {
        padding: 10px;
        margin: 5px;
    } */
    .uf {
        display: flex;
        flex-wrap: wrap
    }

    .u {
        padding: 10px;
    }

    .ub {
        align-items: flex-end width: 200px
    }
</style>
<!-- End Breadcrumbs -->
<?php
      $randomString = Str::random(30)
      ?>
<section class="inner-page ">
    <?php if($no==0): ?>
    <div class="container">

        <a href="<?php echo e(route('fortify.register')); ?>" style="--clr:#ff22bb;--i:0;"><Span>Contribute here !</Span></a>
        <a href="<?php echo e(route('women.explore',['randomString'=>$randomString,'id'=>1,'no'=>'0'])); ?>"
            style="--clr:#ff22bb;--i:0;"><Span>OPPORTUNITIES FOR WOMEN</Span></a>

    </div>
    <?php endif; ?>

    <div class="row u ">
        <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-sm-4 col-xs-12 u">
            <div style="margin: 5px; border:1px solid rgba(212, 212, 212, 0.712); padding:10px;border-radius:10px" class="row section-success  text-center">
                <div class="col-md-12 section1">
                    <?php if($result->post_photo1==null): ?>
                    <img  style="border-radius: 0px; width:455px;height:270px"  src="https://media.geeksforgeeks.org/wp-content/cdn-uploads/20191105192037/What-Are-The-Best-Resources-For-Competitive-Programming.png">
              
                  <?php else: ?>
                    <img style="border-radius: 0px; width:455px;height:270px"  width="455px" src="<?php echo e(url('upload/oppurtunity/'.$result->post_photo1)); ?>">

                    <?php endif; ?>
                </div>
                <div class="col-md-12 section2 pb-3">
                    <p><?php echo e($result->name); ?></p>
                    <?php echo Str::limit($result->description, 30, ' ...'); ?>

                </div>
                <a href="<?php echo e(route('read.more',['id'=>$result->opid])); ?>" class=" ub btn btn-primary">Read More</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/web/content.blade.php ENDPATH**/ ?>