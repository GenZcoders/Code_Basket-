<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <title>Add Category</title>
    <link rel="stylesheet" href="<?php echo e(url('css/file/nicepage.css')); ?>" media="screen">
    <link rel="stylesheet" href="<?php echo e(url('css/file/Home.css')); ?>" media="screen">

    <meta name="generator" content="Nicepage 4.4.3, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


    </head>

    <body data-home-page="Home.html" data-home-page-title="Home" class="u-body u-xl-mode">
        <section class="u-align-center u-clearfix u-section-1" id="sec-a00e">
            <div class="u-align-left u-clearfix u-sheet u-sheet-1">
                <div class="u-form u-form-1">
                    <form action="<?php echo e(route('oppurtunity.store')); ?>" method="POST" enctype="multipart/form-data"
                        class="u-clearfix u-form-spacing-16 u-form-vertical u-inner-form" source="custom" name="form"
                        style="padding: 4px;">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

                        <?php endif; ?>
                        <div class="u-form-group u-form-name u-label-top">
                            <label for="name-5a1e" class="u-label">Oppurtunites Name</label>
                            <input type="text" placeholder="Enter Cateogry Name" id="name-5a1e" name="op_name"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-1">
                        </div>
                        <div class="u-form-group u-form-name u-label-top">
                            <label for="name-5a1e" class="u-label">Description</label>
                            <textarea type="text" placeholder="Enter Url of link" id="name-5a1e" name="desc"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-1"></textarea>
                        </div>
                        <div class="u-form-group u-form-name u-label-top">
                            <label for="name-5a1e" class="u-label">Url Link</label>
                            <input type="text" placeholder="Enter Url of link" id="name-5a1e" name="url_link"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-1">
                        </div>
                        <div class="u-form-group u-form-name u-label-top">
                            <label for="name-5a1e" class="u-label">Url Link 2</label>
                            <input type="text" placeholder="Enter Url of link" id="name-5a1e" name="url_link2"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-1">
                        </div>
                        <div class="u-form-group u-form-name u-label-top">
                            <label for="name-5a1e" class="u-label">Image(1) *</label>
                            <input type="file" placeholder="Enter Cateogry Name" id="name-5a1e" name="image"
                            
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-1">
                        </div>

                        <div class="u-form-group u-label-top u-form-group-2">
                            <label for="text-37e4" class="u-label">Image(optional)</label>
                            <input id="text-37e4" name="image2"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-2"
                                autofocus="autofocus" type="file">
                        </div>

                        <div class="u-form-group u-label-top u-form-group-2">
                            <label for="text-37e4" class="u-label">Is For Women</label>
                            <input type="checkbox" id="vehicle1" name="women" value="0">
                        </div>
                        <div class="u-form-group u-label-top u-form-group-2">
                            <label for="text-37e4" class="u-label">Or For All</label>
                            <input type="checkbox" id="vehicle1" name="all" value="1">
                        </div>

                        <div class="u-form-group u-label-top u-form-group-2">
                            <label for="text-37e4" class="u-label">Choose Categories</label>

                            <select name="op_id"
                                class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-12 u-white u-input-2"
                                id="cars">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category['op_id']); ?>"><?php echo e($category['name']); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="u-align-right u-form-group u-form-submit u-label-top">
                            <input type="submit" value="submit"
                                class="u-border-2 u-border-black u-btn u-btn-submit u-button-style u-hover-palette-2-light-1 u-none u-text-black u-text-hover-white u-btn-1">

                        </div>

                    </form>
                </div>
            </div>
        </section>
        <?php if(Auth::user()->user_role_type=="admin"): ?>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Cateogry Name</th>
                    <td>Link</td>
                    <th scope="col">Image</th>
                    <th scope="col">Image 2</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['name']); ?></td>
                    <td><a href="<?php echo e($data['link']); ?>">Link</a></td>
                    <td><img src="<?php echo e(url('upload/oppurtunity/'.$data['post_photo1'])); ?>" width="100px" height="50px"
                            alt=""></td>
                    <td><?php if($data['post_photo2']==null): ?>
                        No Photo
                        <?php else: ?>
                        <img src="<?php echo e(url('upload/oppurtunity/'.$data['post_photo2'])); ?>" width="100px" height="50px"
                            alt="">


                        <?php endif; ?>
                    </td>

                    <td><?php echo e($data['name']); ?></td>
                    <td>
                        <form action="<?php echo e(route('route.disapprove',['id'=>$data['opid']])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-primary" type="submit" value="Disapprove">
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('oppur.destroy',['id'=>$data['opid']])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-danger" type="submit" value="Delete">
                        </form>
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
        <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/admin/oppurtunities.blade.php ENDPATH**/ ?>