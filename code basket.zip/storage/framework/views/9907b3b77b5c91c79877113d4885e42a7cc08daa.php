<?php echo $__env->make('webLayout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main-section'); ?>
<?php echo $__env->make('webLayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/layouts/main.blade.php ENDPATH**/ ?>