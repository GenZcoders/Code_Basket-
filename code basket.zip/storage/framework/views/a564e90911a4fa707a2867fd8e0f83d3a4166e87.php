
<?php $__env->startSection('main-section'); ?>
<style>
    .read {
        padding: 10px;
    }

    .read h1 {
        padding: 5px;
    }
</style>

<section class="inner-page ">
    <div class="read">
        <br>

        <?php $__currentLoopData = $read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($reads->post_photo1==null): ?>

        <?php else: ?>
        <img style="align-content: center" width="100%" height="493px"
            src="<?php echo e(url('upload/oppurtunity/'.$reads->post_photo1)); ?>">
        <?php endif; ?>

        <h1><?php echo e($reads->name); ?></h1>
        <span>Posted on -<b><?php echo e(date('d M Y', strtotime($reads->created_at))); ?></b></span>
        <hr>
        <pre style="font-family: 'Times New Roman', Times, serif; font-weight:600" ><?php echo e($reads->description); ?></pre>
        <hr>
        <?php if($reads->link==""): ?>
        <?php else: ?>
        <strong> <span style="color: blue;font-size:2rem"><a style="color: rgb(96, 96, 194)"
                    href="<?php echo e($reads->link); ?>">Visit</a></span></strong>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/web/read.blade.php ENDPATH**/ ?>