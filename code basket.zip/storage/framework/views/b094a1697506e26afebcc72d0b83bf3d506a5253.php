<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link id="u-theme-google-font" rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <style>
        .f {
            box-sizing: border-box;
            display: flex;
            border-radius: 10px;
            flex-shrink: inherit;
            flex-wrap: wrap;
            justify-content: center;
        }

        .box {
            /* display: flex; */
            border-radius: 10px;
            margin: 10px;
            padding: 20px;
            justify-content: center;
            width: 300px;
            /* height: 200px; */
            border: 2px solid black;
        }

        .box:hover {
            background: steelblue;
        }

        .mm {
            border-radius: 10px;
            padding: 30px;
            /* background: blue; */
            width: 200px;
            top: 100px;
            position: relative;
            /* margin-top: 50px; */
            bottom: 100px;
            top: -18px;
            width: 100%;
        }

        span {
            font-size: 34px;
            /* color: white;  */
        }
    </style>



    <?php if(Auth::user()->user_role_type=="admin"): ?>


    <?php
  $randomString = Str::random(400)
  ?>

    <div class="f">
        <a href="#">
            <div class="box">
                <h1>Categoty</h1>
                <br>
                <span><?php echo e($num); ?></span>
            </div>

        </a>
        <a href="<?php echo e(route('web.explore',['randomString'=>$randomString,'id'=>1,'no'=>'1'])); ?>">
            <div class="box">
                <h1>Oppurtunities</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>
        <a href="<?php echo e(route('web.explore',['randomString'=>$randomString,'id'=>2,'no'=>2])); ?>">
            <div class="box">
                <h1>RESOURCES</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>


        <a href="<?php echo e(route('web.explore',['randomString'=>$randomString,'id'=>3,'no'=>3])); ?>">
            <div class="box">
                <h1>PROJECTS</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>
        <a href="<?php echo e(route('web.explore',['randomString'=>$randomString,'id'=>4,'no'=>4])); ?>">
            <div class="box">
                <h1>FINANCIAL AID</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>
        <a href="<?php echo e(route('web.explore',['randomString'=>$randomString,'id'=>5,'no'=>5])); ?>">
            <div class="box">
                <h1>FUN AND LEARN</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>
        <a href="">
            <div class="box">
                <h1>APPROVED</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>
        <a href="">
            <div class="box">
                <h1>TOTAL USERS</h1>
                <br>
                <span> <?php echo e($num2); ?></span>
            </div>
        </a>

    </div>
    <?php endif; ?>


    
    <?php if(Auth::user()->user_role_type=="user"): ?>
    <h1> Your Post</h1>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Cateogry Name</th>
                <td>Link</td>
                <th scope="col">Image</th>
                <th scope="col">Image 2</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data['name']); ?></td>
                <td><a href="<?php echo e($data['link']); ?>">Link</a></td>
                <td><img src="<?php echo e(url('upload/oppurtunity/'.$data['post_photo1'])); ?>" width="100px" height="50px" alt="">
                </td>
                <td><?php if($data['post_photo2']==null): ?>
                    No Photo
                    <?php else: ?>
                    <img src="<?php echo e(url('upload/oppurtunity/'.$data['post_photo2'])); ?>" width="100px" height="50px" alt="">


                    <?php endif; ?>
                </td>

                <td><?php echo e($data['name']); ?></td>
                <td>
                    <?php if($data->approved==1): ?>
                    <button disabled class="btn btn-primary">Approved</button>
                    <?php else: ?>
                    <button disabled class="btn btn-primary">Pending</button>

                    <?php endif; ?>
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/dashboard.blade.php ENDPATH**/ ?>