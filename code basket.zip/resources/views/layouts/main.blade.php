@include('webLayout.nav')
@yield('main-section')
@include('webLayout.footer')
